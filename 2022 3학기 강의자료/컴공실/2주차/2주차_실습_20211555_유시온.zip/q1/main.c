#include <stdio.h>
#include "animal.h"

int main(){

	void dog();
	void blackcow();
	void turtle();

	return 0;
}

