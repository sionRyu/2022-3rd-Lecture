#include <stdio.h>

void blackcow(){

	printf("blackcow\n");

	return;
}
