#!/bin/bash

echo'Working directory'
read dirname

if [ -n "$dirname" ]
then
	if [ -d "$dirname" ]
		then
	else
		echo "error"
		exit 0
	fi
fi

for dir in $dirname/*
echo $dir
do

newname='echo $dir | tr "[a-z] [A-Z" "[A-Z] {a-z}"'
mv $dir $newname
done

